import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'

const root = '/tmp/pr10646-feedback'
const base = '4888710407feab891daecf37800038d258712b95'
const head = '7cfb34c8896082ee72ba748e9d69880ff95d4833'
assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), head)
const reports = []
for (const [kind, expected, required] of [
  ['operations', 433, ['apis/api-auth/src/operations.ts', 'apis/api-auth/src/reads.ts', 'apis/api-auth/src/store.ts', 'apis/api-journeys/src/lib/mcpEdits.ts', 'apis/api-journeys/src/lib/mcpEditsStore.ts', 'apis/api-mcp/src/release.ts', 'tools/scripts/mcp-release.mjs', 'tools/scripts/mcp-operations.mjs', 'apis/api-auth/src/mediaJobs.ts', 'apis/api-media/src/lib/mcpMediaJobs.ts', 'apis/api-media/src/lib/mcpMediaRuntime.ts']],
  ['video', 309, ['apis/api-auth/src/mediaJobs.ts', 'apis/api-media/src/lib/mcpMediaJobs.ts', 'apis/api-media/src/lib/mcpMediaExecutor.ts', 'apis/api-media/src/lib/mcpMediaJobHttp.ts', 'apis/api-media/src/lib/mcpVideoInput.ts', 'apis/api-media/src/lib/mcpVideoProvider.ts', 'apis/api-journeys/src/lib/mcpMediaClient.ts', 'apis/api-journeys/src/lib/mcpEdits.ts', 'apis/api-journeys/src/lib/mcpStructureHistory.ts', 'apis/api-media/src/lib/mcpMediaSources.ts', 'apis/api-media/src/lib/mcpMediaMutations.ts', 'apis/api-media/src/lib/mcpMediaProviders.ts', 'apis/api-media/src/lib/mcpMediaRuntime.ts', 'libs/prisma/media/src/client.ts', 'libs/yoga/src/mcp/mediaContract.ts']]
]) {
  const directory = kind === 'video' ? `${root}/hosted-video` : 'coverage/integration/mcp-operations'
  const tests = JSON.parse(readFileSync(`${directory}/test-results.json`))
  assert.equal(tests.numTotalTests, expected)
  assert.equal(tests.numPassedTests, expected)
  assert.equal(tests.numFailedTests, 0)
  assert.equal(tests.numPendingTests, 0)
  assert.equal(tests.numTodoTests, 0)
  const coverage = JSON.parse(readFileSync(`${directory}/coverage-final.json`))
  const cobertura = readFileSync(`${directory}/cobertura-coverage.xml`, 'utf8')
  const filenames = [...cobertura.matchAll(/filename="([^"]+)"/g)].map(m => m[1])
  assert(filenames.length > 0)
  assert(filenames.every(p => !p.startsWith('/') && !p.includes('\\')))
  const executions = required.map(file => {
    const data = Object.entries(coverage).find(([path]) => path.endsWith('/' + file))?.[1]
    assert(data, `Missing ${file}`)
    const hitStatements = Object.values(data.s).filter(n => n > 0).length
    assert(hitStatements > 0, `Unexecuted ${file}`)
    assert(filenames.includes(file), `Missing relative path ${file}`)
    return { file, hitStatements }
  })
  const assertions = tests.testResults.flatMap(f => f.assertionResults.map(t => ({ name: t.fullName, status: t.status, durationMs: t.duration })))
  reports.push({ kind, source: kind === 'video' ? 'completed hosted run, identical Git tree proven in video-tree-proof.json' : 'fresh exact-head local rerun', passed: expected, failed: 0, skipped: 0, todo: 0, repositoryRelativeCoberturaFiles: filenames.length, executions, assertions })
  for (const file of ['test-results.json', 'coverage-final.json', 'cobertura-coverage.xml']) {
    writeFileSync(`${root}/publish/${kind}-${file}`, readFileSync(`${directory}/${file}`))
  }
  const log = kind === 'video' ? readFileSync(`${root}/current-video.log`, 'utf8').split('\n').filter(l => l.includes('Exercise same-job video ingress, recovery, cancellation and separate draft attachment')).join('\n') : readFileSync(`${root}/${kind}-rerun.log`, 'utf8')
  writeFileSync(`${root}/publish/rerun-${kind}.log`, log.replace(/\u001b\[[0-9;]*m/g, '').replace(/(postgres(?:ql)?:\/\/[^:\s/]+:)[^@\s]+@/g, '$1<REDACTED>@'))
}
const coverage = JSON.parse(readFileSync('coverage/integration/mcp-operations/coverage-final.json'))
const paths = execFileSync('git', ['diff', '--name-only', base, head], { encoding: 'utf8' }).trim().split('\n').filter(p => !p.includes('.spec.') && (/\/src\/.*\.ts$/.test(p) || ['tools/scripts/mcp-operations.mjs', 'tools/scripts/mcp-release.mjs'].includes(p)))
const modules = paths.map(file => {
  const data = Object.entries(coverage).find(([p]) => p.endsWith('/' + file))?.[1]
  assert(data, `Missing changed module ${file}`)
  const changed = new Set(); let line = 0
  for (const s of execFileSync('git', ['diff', '--unified=0', base, head, '--', file], { encoding: 'utf8' }).split('\n')) {
    const h = s.match(/^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@/)
    if (h) { line = Number(h[1]); continue }
    if (s.startsWith('+++') || s.startsWith('---')) continue
    if (s.startsWith('+')) changed.add(line++)
    else if (s.startsWith(' ')) line++
  }
  const statements = Object.entries(data.statementMap).filter(([, s]) => changed.has(s.start.line))
  const lines = new Set(statements.map(([, s]) => s.start.line))
  const hit = new Set(statements.filter(([id]) => data.s[id] > 0).map(([, s]) => s.start.line))
  return { file, changedExecutableLines: lines.size, coveredChangedLines: hit.size, uncovered: [...lines].filter(l => !hit.has(l)) }
})
const summary = { head, base, recordedAt: new Date().toISOString(), reports, modules, changedExecutableLines: modules.reduce((n, m) => n + m.changedExecutableLines, 0), coveredChangedLines: modules.reduce((n, m) => n + m.coveredChangedLines, 0) }
const mcpLog = readFileSync(`${root}/mcp-rerun.log`, 'utf8')
assert.match(mcpLog, /Tests\s+179 passed \(179\)/)
assert.doesNotMatch(mcpLog, /\d+ failed|\d+ skipped/)
summary.mcp = { passed: 179, failed: 0, skipped: 0, source: 'fresh full workspace run' }
const cli = JSON.parse(readFileSync(`${root}/publish/cli-smokes.json`))
assert.deepEqual(cli.map(c => c.code), [0, 1, 0, 1])
assert.match(readFileSync(`${root}/cli-smokes.log`, 'utf8'), /4 CLI entry smokes passed/)
summary.cli = { passed: 4, failed: 0, instrumented: false, controlledStatusServer: true }
writeFileSync(`${root}/publish/verified-results.json`, JSON.stringify(summary, null, 2))
const checksums = readdirSync(`${root}/publish`).filter(n => n !== 'SHA256SUMS').map(name => createHash('sha256').update(readFileSync(`${root}/publish/${name}`)).digest('hex') + '  ' + name).join('\n') + '\n'
writeFileSync(`${root}/publish/SHA256SUMS`, checksums)
console.log(JSON.stringify({ head, base, reports: reports.map(({ kind, passed, failed, skipped }) => ({ kind, passed, failed, skipped })), changedExecutableLines: summary.changedExecutableLines, coveredChangedLines: summary.coveredChangedLines }, null, 2))
