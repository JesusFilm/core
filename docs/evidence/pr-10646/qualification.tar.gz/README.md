# PR 10646 qualification evidence

Qualified source head: 7cfb34c8896082ee72ba748e9d69880ff95d4833
Integrated immediate parent: 4888710407feab891daecf37800038d258712b95
Complete Git tree: c4b19ffccfa4833ecd1aafdf029eb66c6b00a565

This bundle restores reviewer access to evidence cited in PR 10646. Original command logs survived. The original raw local video and operations reports did not survive, so the reports here have explicit replacement provenance. They are not described as the missing original reports.

- original-video.log, original-operations.log and original-mcp.log are the retained logs of the earlier 309, 433 and 179 passing runs. original-coverage-summary.json is the retained changed-line calculation, not a substitute for raw coverage.
- operations-test-results.json, operations-coverage-final.json and operations-cobertura-coverage.xml are from a fresh complete local operations run at the pinned head, with Node 24.22.3 and isolated PostgreSQL 16.16. rerun-operations.log contains its command output.
- video-test-results.json, video-coverage-final.json and video-cobertura-coverage.xml are the complete hosted 309-case report from job 139816740312. video-tree-proof.json proves the hosted checkout and pinned head have the identical complete Git tree, including source, tests and configuration. rerun-video.log contains the hosted video command step. The hosted artifact also remains at https://github.com/JesusFilm/core/actions/runs/45793079642/artifacts/15106285972.
- rerun-mcp.log is the fresh 179-case MCP workspace run.
- cli-smokes.json, cli-smokes.mjs and cli-smokes.log are separate process checks. They exercise manifest validation, the missing-manifest failure, operations status against a controlled loopback server, and invalid-command rejection. They do not contribute to instrumented coverage.
- verified-results.json records all test names/statuses, required owning-module execution, repository-relative Cobertura filenames and the changed-line calculation against the pinned immediate parent. validate-evidence.mjs performs those checks.
- original-lint.log and original-typecheck.log are the earlier required pre-push checks. No source changes are needed to share this evidence.

A duplicate local video attempt was interrupted with exit 130 after the identical-tree hosted report was verified. Its partial output is retained in cancelled-duplicate-video.log for transparency and supplies no qualification claim. All 309 required video cases completed in the hosted report with zero failures or skips.

Firebase identity, upload storage and external media providers were controlled. OAuth, grants, MCP HTTP, gateway, owning service code and PostgreSQL were real. This is local/automated source evidence. AWS, ingress, live providers, deployed rollback, browser and real-client checks remain deferred in the PR.

The hosted operations job separately failed 5 of 433 cases, with 428 passed. Its artifact has test results only and cannot supply passing owning coverage. That failure is not hidden by the replacement local run. See https://github.com/JesusFilm/core/actions/runs/45793079765/job/139816740580. No causal fix for those hosted failures is claimed.

SHA256SUMS records every file in this archive. Extract qualification.tar.gz into an empty directory, then run sha256sum -c SHA256SUMS. The surrounding repository index records the archive checksum and links the complete command logs, test results, coverage reports and provenance.
