import assert from 'node:assert/strict'
import {spawn} from 'node:child_process'
import {createServer} from 'node:http'
import {writeFileSync} from 'node:fs'
const evidence=[]
async function run(args,expected,env=process.env){
 const child=spawn(process.execPath,args,{env});let out='',err=''
 child.stdout.on('data',x=>out+=x);child.stderr.on('data',x=>err+=x)
 const code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',resolve)})
 assert.equal(code,expected,err+out);evidence.push({args,code});return out
}
const manifest='tools/scripts/mcp-operations.stage.example.json'
assert.equal(JSON.parse(await run(['tools/scripts/mcp-release.mjs',manifest],0)).qualification,'unexecuted')
assert.match(await run(['tools/scripts/mcp-release.mjs'],1),/Release check failed/)
const status={controls:[{control:'admission',enabled:false,generation:1},{control:'effects',enabled:false,generation:2}],accepted:[],pendingChanges:0}
let requests=0
const server=createServer(async(req,res)=>{
 requests++;assert.equal(req.url,'/internal/operations');assert.equal(req.headers.authorization,'Bearer controlled-operations-cli-secret-at-least-32')
 let raw='';for await(const chunk of req)raw+=chunk;assert.deepEqual(JSON.parse(raw),{action:'status'})
 res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(status))
})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
try{
 const env={...process.env,AUTH_ISSUER:`http://127.0.0.1:${server.address().port}`,AUTH_OPERATIONS_SECRET:'controlled-operations-cli-secret-at-least-32'}
 assert.deepEqual(JSON.parse(await run(['tools/scripts/mcp-operations.mjs','status'],0,env)),status)
 assert.match(await run(['tools/scripts/mcp-operations.mjs','invalid'],1,env),/Operational control failed/)
 assert.equal(requests,1)
}finally{await new Promise(resolve=>server.close(resolve))}
writeFileSync('/tmp/pr10646-review/cli-smokes.json',JSON.stringify(evidence,null,2));console.log('4 CLI entry smokes passed, including both expected failure exit codes; operations used a controlled loopback fixture.')
