const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const source = fs.readFileSync('apis/api-auth/test/grantedVideoUpload.spec.ts', 'utf8')
const fixture = fs.readFileSync('apis/api-auth/test/grantedStructureFixture.ts', 'utf8')
const guard = source.slice(source.indexOf('  const issue = /^'), source.indexOf('  const media ='))
const setup = source.slice(source.indexOf('  const f = structureFixture({'), source.indexOf('    authEnv:'))
const check = fixture.slice(fixture.indexOf('    const issue =\n'), fixture.indexOf('    for (const table of ['))
for (const ticket of ['10554', '10565']) {
 const namespace = ticket === '10554' ? ticket : ticket + '_a1b2c3'
 const context = {
  URL, Error, process: { env: {} },
  authUrl: 'postgresql://localhost/auth_issue_' + namespace + '_auth',
  journeysUrl: 'postgresql://localhost/journeys_issue_' + namespace + '_journeys',
  mediaUrl: 'postgresql://localhost/media_issue_' + namespace + '_media',
  structureFixture(options) { vm.runInNewContext(check, {...context, options}) }
 }
 const jsGuard=guard.replace('mediaUrl!', 'mediaUrl')
 vm.runInNewContext(jsGuard + setup + '  })', context)
 console.log(ticket, 'outer and shared fixture guards passed')
}

for (const name of ["media", "media_issue_10564_temp", "media_issue_105650_temp", "media_issue_10565production", "media_issue_10554production", "production_media_issue_10565_temp"]) {
 assert.throws(() => vm.runInNewContext(guard.replace("mediaUrl!", "mediaUrl"), {URL, Error, mediaUrl: "postgresql://localhost/"+name}));
}
console.log("six unsafe namespace names rejected")
for (const [mediaTicket, otherTicket] of [['10554','10565'],['10565','10554']]) {
 const context = {
  URL, Error, process: { env: {} },
  authUrl: 'postgresql://localhost/auth_issue_' + otherTicket,
  journeysUrl: 'postgresql://localhost/journeys_issue_' + otherTicket,
  mediaUrl: 'postgresql://localhost/media_issue_' + mediaTicket,
  structureFixture(options) { vm.runInNewContext(check, {...context, options}) }
 }
 assert.throws(() => vm.runInNewContext(guard.replace('mediaUrl!', 'mediaUrl') + setup + ' })', context), /Use isolated issue databases/)
}
console.log('mismatched auth and Journeys ticket namespaces rejected')
